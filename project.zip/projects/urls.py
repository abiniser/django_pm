from django.urls import path, include

from . import views

urlpatterns = [
    path('', views.projectlistview.as_view(),name='project_list' ),
    path('project/create', views.projectCreateview.as_view(), name= 'project_create' ),
    path('project/edit<int:pk>', views.projectUpdateview.as_view(), name= 'project_update' )

]